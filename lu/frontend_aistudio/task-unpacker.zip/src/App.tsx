/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import TaskUnpacker from './components/TaskUnpacker';

export default function App() {
  return <TaskUnpacker />;
}
